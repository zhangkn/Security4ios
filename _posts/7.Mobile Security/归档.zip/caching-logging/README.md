## 缓存与日志

* [避免缓存应用程序数据](avoid-caching-app-data.md)
* [避免崩溃日志](avoid-crash-logs.md)
* [限制缓存用户名](limit-caching-of-username.md)
* [谨慎管理调试日志](carefully-manage-debug-logs.md)
* [注意键盘缓存](be-aware-of-the-keyboard-cache.md)
* [注意复制和粘贴](be-aware-of-copy-paste.md)
